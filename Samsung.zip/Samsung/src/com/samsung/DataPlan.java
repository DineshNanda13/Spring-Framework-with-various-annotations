package com.samsung;

public interface DataPlan {
	
	public String getDataPlan();

}
