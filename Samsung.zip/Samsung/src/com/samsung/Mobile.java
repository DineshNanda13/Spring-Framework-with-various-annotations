package com.samsung;

public interface Mobile {
	
	public String getVersion();
	
	public String getDailyDataPlan();

}
